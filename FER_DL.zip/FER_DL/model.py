######################

import tensorflow as tf
from tensorflow import keras

import random
import numpy as np
import skimage
import skimage.io as skimg
import skimage.transform as sktransform
import matplotlib.pyplot as plt

######################

#image size
image_size_0 = 350
image_size_1 = 350
image_size = image_size_0 * image_size_1

#dataset structure
training_size = 342
training_path = 'dataset/train'
validation_size = 103
validation_path = 'dataset/validation'

#batch related
batch_size = 89
total_batch = (training_size + batch_size - 1) // batch_size
current_batch = 0

#Stats
acc = [0 for i in range(8)]
tot = [0 for i in range(8)]

#general
def random_rotation(img):
	deg = random.uniform(-25, 25)
	return sktransform.rotate(img, deg)
	
def random_noise(img):
	return skimage.util.random_noise(img)
	
def horizontal_flip(img):
	return img[:, ::-1]

def img_transform(img):
	mask = round(random.uniform(-0.4, 7.4))
	
	if(mask & 1):
		img = horizontal_flip(img)
	
	if(mask & 2):
		img = random_rotation(img)
	
	if(mask & 4):
		img = random_noise(img)
	
	return img

def read_photo(addr, random_transformation):
	img = skimg.imread(addr, as_gray = True)
	#img = sktransform.resize(img, (image_size_0, image_size_1))
	
	if(random_transformation):
		img = img_transform(img)
	
	return img

def get_batch(where, st, ed):
	x_batch = []
	y_batch = []
	
	for i in range(st, ed):
		img = read_photo(where + '/photo/' + str(i+1) + '.png', where == training_path).reshape([image_size_0, image_size_1, 1])
		x_batch.append(img)
		
		yh = open(where + '/tag/' + str(i+1) + '.txt');
		y = int(yh.readline())
		label = [0, 0, 0, 0, 0, 0, 0, 0]
		label[y] = 1
		y_batch.append(label)

	return x_batch, y_batch

def next_batch():
	global current_batch
	
	st = current_batch*batch_size
	ed = min(training_size, (current_batch + 1)*batch_size)
	
	x_batch, y_batch = get_batch(training_path, st, ed)
	current_batch = current_batch + 1

	print("\tCurrent batch: ", current_batch)

	return x_batch, y_batch, ed - st

#cnn utils
def convolutional_layer(input_data, num_input_channels, num_filters, filter_shape, pool_shape, strides, name):
	conv_filt_shape = [filter_shape[0], filter_shape[1], num_input_channels, num_filters]
	
	weights = tf.Variable(tf.truncated_normal(conv_filt_shape, stddev = 0.03), name = name + '_w')
	bias = tf.Variable(tf.truncated_normal([num_filters]), name = name + '_b')

	out_layer = tf.nn.relu(tf.nn.conv2d(input_data, weights, [1, 1, 1, 1], padding = 'SAME') + bias, name = name + '_c')
	
	ksize = [1, pool_shape[0], pool_shape[1], 1]
	
	out_layer = tf.nn.max_pool(out_layer, ksize = ksize, strides = strides, padding = 'SAME', name = name)
	
	return out_layer

def dense_layer(input_data, input_size, output_size, act_function, name):
	wd1 = tf.Variable(tf.truncated_normal([input_size, output_size], stddev = 0.03), name = name + '_w')
	bd1 = tf.Variable(tf.truncated_normal([output_size], stddev = 0.01), name = name + '_b')
	
	return act_function(tf.matmul(tf.reshape(input_data, (-1, input_size)), wd1) + bd1, name = name)

def fit():
	global current_batch
	validation_images, validation_labels = get_batch(validation_path, 0, validation_size)
	
	x = tf.placeholder(tf.float32, [None, image_size_0, image_size_1, 1])
	y = tf.placeholder(tf.float32, [None, 8])
	
	c1 = convolutional_layer(x, 1, 4, [3, 3], [2, 2], [1, 2, 2, 1], 'c1')
	c2 = convolutional_layer(c1, 4, 8, [3, 3], [2, 2], [1, 5, 5, 1], 'c2')
	
	d1 = dense_layer(c2, 8*(image_size_0//10)*(image_size_1//10), 1000, tf.nn.relu, 'd1')
	
	d2 = dense_layer(d1, 1000, 8, tf.identity, 'd2')
	
	y_ = tf.nn.softmax(d2, name = 'y_')
	
	cross_entropy = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits = d2, labels = y))
	optimizer = tf.train.AdamOptimizer(learning_rate = 0.0001).minimize(cross_entropy)
	correct_prediction = tf.equal(tf.argmax(y, 1), tf.argmax(y_, 1))
	accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
	
	#init
	init_op = tf.global_variables_initializer()
	
	best = 0
	
	with tf.Session() as sess:
		tf.compat.v1.train.write_graph(sess.graph.as_graph_def(), '', 'graph.pb', as_text = True)
		sess.run(init_op)
		saver = tf.compat.v1.train.Saver()
		
		for epoch in range(2500):
			current_batch = 0
			
			print("Epoch:", epoch + 1)
			
			for it in range(total_batch):
				batch_x, batch_y, current_batch_size = next_batch()
				_, c = sess.run([optimizer, cross_entropy], feed_dict = {x: batch_x, y: batch_y})
				
			aux = accuracy.eval({x: validation_images, y: validation_labels})
			print("\tAccuracy =", aux)
			
			if(best < aux):
				best = aux
				saver.save(sess, 'tmp.ckpt')
		
		print("Best =", best)
		
		#manual testing
		#img = skimg.imread('img.png', as_gray = True).reshape([-1, image_size])
		#print(sess.run(y_, feed_dict = {x: img}))
	
#Exec
if __name__ == "__main__":
		fit()
