
import cv2

import numpy as np
import skimage.io as skimg
import skimage.transform as sktransform
import matplotlib.pyplot as plt

#image size
image_size_0 = 350
image_size_1 = 350
image_size = image_size_0 * image_size_1

net = cv2.dnn.readNetFromTensorflow('frozen_graph.pb')

img = skimg.imread('img.png', as_gray = True).reshape([image_size_0, image_size_1, 1])

net.setInput(cv2.dnn.blobFromImage(img))

ans = net.forward()

print(ans)
