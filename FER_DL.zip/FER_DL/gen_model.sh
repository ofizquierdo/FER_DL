#!/bin/bash

python3 ~/miniconda3/lib/python3.6/site-packages/tensorflow/python/tools/freeze_graph.py \
--input_graph=graph.pb \
--input_checkpoint=tmp.ckpt \
--output_graph=frozen_graph.pb \
--output_node_names="y_"
